package com.callback.account.request;

public class Accounts {

	private String fiType;
	private String fipId;
	private String accType;
	private String linkRefNumber;
	private String maskedAccNumber;

	public String getFiType() {
		return fiType;
	}

	public void setFiType(String fiType) {
		this.fiType = fiType;
	}

	public String getFipId() {
		return fipId;
	}

	public void setFipId(String fipId) {
		this.fipId = fipId;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getLinkRefNumber() {
		return linkRefNumber;
	}

	public void setLinkRefNumber(String linkRefNumber) {
		this.linkRefNumber = linkRefNumber;
	}

	public String getMaskedAccNumber() {
		return maskedAccNumber;
	}

	public void setMaskedAccNumber(String maskedAccNumber) {
		this.maskedAccNumber = maskedAccNumber;
	}

	public Accounts(String fiType, String fipId, String accType, String linkRefNumber, String maskedAccNumber) {
		super();
		this.fiType = fiType;
		this.fipId = fipId;
		this.accType = accType;
		this.linkRefNumber = linkRefNumber;
		this.maskedAccNumber = maskedAccNumber;
	}

	// Getters and setters for fiType, fipId, accType, linkRefNumber, and
	// maskedAccNumber

}
