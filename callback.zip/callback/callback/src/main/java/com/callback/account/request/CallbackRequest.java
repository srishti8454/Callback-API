package com.callback.account.request;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CallbackRequest {

	private String txnId;
	private String consentStatus;
	private List<Accounts> accounts;
	private String userId;

	// Getters and setters for txnId, consentStatus, accounts, and userId

	public String getTxnId() {
		return txnId;
	}

	public CallbackRequest() {
		super();
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getConsentStatus() {
		return consentStatus;
	}

	public void setConsentStatus(String consentStatus) {
		this.consentStatus = consentStatus;
	}

	public List<Accounts> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Accounts> accounts) {
		this.accounts = accounts;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public CallbackRequest(String txnId, String consentStatus, List<Accounts> accounts, String userId) {
		super();
		this.txnId = txnId;
		this.consentStatus = consentStatus;
		this.accounts = accounts;
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "CallbackRequest [txnId=" + txnId + ", consentStatus=" + consentStatus + ", accounts=" + accounts
				+ ", userId=" + userId + "]";
	}

}
