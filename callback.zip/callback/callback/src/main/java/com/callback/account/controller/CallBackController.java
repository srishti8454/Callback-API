package com.callback.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.callback.account.request.CallbackRequest;
import com.callback.account.response.CallbackResponse;
import com.callback.account.service.CallBackService;
import com.google.gson.Gson;

@RestController
public class CallBackController {

	@Autowired
	private CallbackResponse callbackResponse;

	@Autowired
	private CallBackService callBackService;

	@Autowired
	private CallbackRequest callbackRequest;
	
	@Autowired
	public Gson gson; 

	@PostMapping("/fiu_callback/ConsentNotification/")
	public CallbackResponse callback(@RequestBody CallbackRequest callbackRequest) throws Exception {
		String userInput = gson.toJson(callbackRequest);
		System.out.println("The user input is "+userInput);
		try {

			callbackResponse = callBackService.callback(callbackRequest);
		} catch (Exception ex) {

			System.out.println("Something went wrong");

		}
		return callbackResponse;

	}

}
