package com.callback.account.response;

import org.springframework.stereotype.Component;

@Component
public class CallbackResponse {

	private String msgCd;
	private Head head;

	public CallbackResponse(String msgCd, Head head) {
		super();
		this.msgCd = msgCd;
		this.head = head;
	}

	public CallbackResponse() {
		super();
	}

	public String getMsgCd() {
		return msgCd;
	}

	public void setMsgCd(String msgCd) {
		this.msgCd = msgCd;
	}

	public Head getHead() {
		return head;
	}

	public void setHead(Head head) {
		this.head = head;
	}

	@Override
	public String toString() {
		return "CallbackResponse [msgCd=" + msgCd + ", head=" + head + "]";
	}

	// Getters and setters for msgCd and head

}
