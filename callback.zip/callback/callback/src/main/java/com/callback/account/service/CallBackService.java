package com.callback.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.callback.account.request.CallbackRequest;
import com.callback.account.response.CallbackResponse;
import com.callback.account.response.Head;
import com.google.gson.Gson;

@Service
public class CallBackService {

	@Autowired
	private CallbackResponse callbackResponse;

	@Autowired
	private Head head;

	@Autowired
	public Gson gson;

	public CallbackResponse callback(CallbackRequest callbackRequest) {

		System.out.println("inside call back service first line");

		if (callbackRequest.getConsentStatus().equalsIgnoreCase("READY")) {

			callbackResponse.setMsgCd("Success");
			head.setStatusCd("200");
			head.setTxnID("9dc6280b-e051-4ef9-aa77-700dabaf0bb6");
			String headOutPut = gson.toJson(head);

			System.out.println("the value of head output is:" + headOutPut);

			callbackResponse.setHead(head);

			System.out.println("inside if call back service first line");

			return callbackResponse;

		}
		System.out.println("Line after if block");

		callbackResponse.setMsgCd("FAILED");
		head.setStatusCd("101");
		head.setTxnID("9dc6280b-e051-4ef9-aa77-700dabaf0bb6");
		callbackResponse.setHead(head);
		String headOutPut = gson.toJson(head);

		System.out.println("the value of head output is:" + headOutPut);

		callbackResponse.setHead(head);

		System.out.println("line before null");
		return callbackResponse;
	}

}
