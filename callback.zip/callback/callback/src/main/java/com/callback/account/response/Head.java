package com.callback.account.response;

import org.springframework.stereotype.Component;

@Component
public class Head {

	private String statusCd;
	private String txnID;
	
	

	public Head() {
		super();
	}

	public Head(String statusCd, String txnID) {
		super();
		this.statusCd = statusCd;
		this.txnID = txnID;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getTxnID() {
		return txnID;
	}

	public void setTxnID(String txnID) {
		this.txnID = txnID;
	}

	@Override
	public String toString() {
		return "Head [statusCd=" + statusCd + ", txnID=" + txnID + "]";
	}

}
